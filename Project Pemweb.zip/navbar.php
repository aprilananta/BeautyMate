<?php
// Memulai session
session_start();

/*
// Jika pengguna telah login, tampilkan username
if(isset($_SESSION['username'])) {
    echo "Selamat datang, " . $_SESSION['username'];
} else {
    echo "Selamat datang, Tamu";
}
?>
*/ 